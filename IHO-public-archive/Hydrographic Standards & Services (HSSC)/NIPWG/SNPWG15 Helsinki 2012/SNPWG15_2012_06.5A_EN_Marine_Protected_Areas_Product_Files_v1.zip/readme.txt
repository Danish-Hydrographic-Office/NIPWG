CONTENTS

schemas/
	0.2/	MPA schemas
	gml/	GML 3.2.1 schemas
	iso/	ISO schemas used by GML and MPA schemas
	S100/	XML schemas implementing the generic S100 types (not official implementations)
	xlink/	XLink XML schemas, used by GML and MPA schemas

BRMPAExSet01/	Exchange set for Brazil data

USMPAExSet01/	Exchange set for US East Coast data

USSTWBANK1/	Exchange set of Stellwagen Bank data

USSTWBANK2/	Exchange set of Stellwagen Bank data

USSTWBANK3/	Exchange set of Stellwagen Bank data

USMPAExSet02/	Exchange set for US Hawaii data

JusslandExSet01/	Exchange set for Micklefirth data

MPA_3_4_0.jpg	Updated application schema UML diagram

NPUBSDQModel.jpg	Data quality model for nautical publications

NOAAExample.jpg	(Old) Screen capture with Snowflake Software GML viewer

SnowflakeOrder.jpg	Suggested order for Snowflake Software viewer


NOTES

The exchange sets include CATALOG files with metadata.
The datasets in BRMPAExSet01, USMPAExSet01 and USMPAExSet02 include a new data quality object, with made-up coordinates.
The 3 Stellwagen Bank data sets are small exchange sets created from the 3 Stellwagen Bank mappings, with local links, online links and text.

To use the Snowflake viewer styles file:
(1) Start the viewer. 
(2) Click the Layer Order menu button (it is the layers icon with the tooltip "Change the redraw and selection priority of the layers").
(3) Load the styles file colourlist.xml (or another one you created) with the Load button in the layer order priority window.
(4) Apply the styles by clicking the Apply button.
(5) Load the GML data file in the viewer window (e.g., with drag and drop).

The free GML viewer from Snowflake software is not documented and is not good at styles, for example it rearranges the order of feature types, which means that large features may hide smaller features and the order has to be changed every time the viewer is executed.
